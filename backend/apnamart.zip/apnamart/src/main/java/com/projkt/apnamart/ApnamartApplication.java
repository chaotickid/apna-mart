package com.projkt.apnamart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApnamartApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApnamartApplication.class, args);
	}

}
